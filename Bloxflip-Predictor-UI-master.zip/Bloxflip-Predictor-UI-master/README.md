# Bloxflip Mines Mirror
A simple ui design made for mirroring the bloxflip mines games real time also being able to have all the mines functionalities!
